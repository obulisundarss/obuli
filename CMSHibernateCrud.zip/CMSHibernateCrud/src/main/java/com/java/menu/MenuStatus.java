package com.java.menu;

public enum MenuStatus {
	AVAILABLE,NOTAVAILABLE
}
