package com.java.infinte;

import java.sql.Date;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

public class RoomDAO {
	
	private static Session sess;
	private Query q;
	
	static {
		sess=new SessionHelper().getsession();
	}
	
	public String generateroomid() {
		q=sess.createQuery("select max(room.roomid) from Room room");
		List<String> roomid=q.list();
		String newroomid=null;
		
		if(roomid.get(0) == null) {
			return "R001";
		}
		int roomno=  Integer.parseInt(roomid.get(0).substring(1));
		++roomno;
		
		
		if(roomno >= 0 && roomno < 10) {
			newroomid="R00"+roomno;
		}else if(roomno >= 10 && roomno <100) {
			newroomid="R0"+roomno;
		}else {
			newroomid="R"+roomno;
		}
        sess.clear();		
		return newroomid;
	}
	
	
	public String generateBookingid() {
		q=sess.createQuery("select max(bk.bookid) from Booking bk");
		List<String> bookingid=q.list();
		String newbookid=null;
		
		if(bookingid.get(0) == null) {
		   return "B001";
		  
		}
		int bookid=  Integer.parseInt(bookingid.get(0).substring(1));
		++bookid;
		if(bookid >= 0 && bookid < 10) {
			newbookid="B00"+bookid;
		}else if(bookid >= 10 && bookid <100) {
			newbookid="B0"+bookid;
		}else {
			newbookid="B"+bookid;
		}
		sess.clear();	
		return newbookid;
		
	}
	
	public void AddRoom(Room room) {
        room.setRoomid(generateroomid());	
        Transaction t = sess.beginTransaction();
 		sess.save(room);
 		t.commit();	
	}
	
	public void NewBooking(Booking booking) {
		booking.setBookid(generateBookingid());
		booking.setBookdt(new Date(System.currentTimeMillis()));
		Transaction t = sess.beginTransaction();
 		sess.save(booking);
 		t.commit();
 		UpdateRoomStatus(booking.getRoomid());		
 		
	}
	
	public void UpdateRoomStatus(String roomid) {
		q=sess.createQuery(" from Room where roomid ='"+roomid+"'");
		List<Room> rooms=q.list();
		Room rd=rooms.get(0);
		rd.setStatus("BOOKED");
		Transaction t = sess.beginTransaction();
 		sess.save(rd);
 		t.commit();	
	}
	
	public List<Room> getAvailablerooms(){
		q=sess.createQuery(" from Room where Status='AVAILABLE'");
		List<Room> rooms=q.list();
		return rooms;
	}
	
	public List<Booking> getallbookings(){
		q=sess.createQuery("from Booking where ChkOutDate is null");
		List<Booking> bookings=q.list();	
		return bookings;
	}
	
	
	public List<Booking> allbookings(){
		q=sess.createQuery("from Booking ");
		List<Booking> bookings=q.list();	
		return bookings;
	}
	
	public List<Billing> allbillings(){
		q=sess.createQuery("from Billing");
		List<Billing> bills=q.list();
		return bills;
	}
	
	public int CheckedoutofRoom(Billing bil,Date dt) {
		int costperday=0;
		int totbill;
		Date chindt=null;
		q=sess.createQuery(" from Room where Status='BOOKED'");
		List<Room> rooms=q.list();
		List<Booking> bookings=getallbookings();
		for (Booking booking : bookings) {
			if(booking.getBookid().equals(bil.getBookid())) {
				booking.setCheckoutdt(dt);
				chindt=booking.getCheckindt();
				Transaction t = sess.beginTransaction();
		 		sess.save(booking);
		 		t.commit();
			}
		}
		
		
		for (Room room : rooms) {
			if(room.getRoomid().equals(bil.getRoomid())) {
				costperday=room.getCostperday();
				room.setStatus("AVAILABLE");
				Transaction t = sess.beginTransaction();
		 		sess.save(room);
		 		t.commit();
			}
		}
		
		long difference_In_Time
        = dt.getTime() - chindt.getTime();
		
		int days
        = (int)(difference_In_Time
           / (1000 * 60 * 60 * 24))
          % 365;
		
		++days;
		
		totbill=days*costperday;
		
		bil.setNo_of_days(days);
		bil.setBillamt(totbill);
		
		Transaction t = sess.beginTransaction();
 		sess.save(bil);
 		t.commit();
 		
 		sess.clear();
 		
 		return totbill;
		
		
	}


}
