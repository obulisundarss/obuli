package com.java.infinte;

public enum Status {	
	AVAILABLE,BOOKED
}
