package infinite.ComplaintClientD;

public enum Status {
	
	
	PENDING, RESOLVED

}
