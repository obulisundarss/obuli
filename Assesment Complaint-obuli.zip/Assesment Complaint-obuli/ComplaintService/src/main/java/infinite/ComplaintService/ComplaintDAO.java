package infinite.ComplaintService;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;





public class ComplaintDAO {
	
	Connection connection;
	PreparedStatement pst;
	
	public String addComplaint(Complaint complaint) throws ClassNotFoundException, SQLException {
		connection=ConnectionHelper.getConnection();
		String cmd="Insert into Complaint(ComplaintID,ComplaintType,CDescription,ComplaintDate,Severity)"
		+"values(?,?,?,?,?)";
		pst=connection.prepareStatement(cmd);
		pst.setInt(1, complaint.getComplaintID());
		pst.setString(2, complaint.getComplaintType());
		pst.setString(3, complaint.getcDescription());
		long o1=System.currentTimeMillis();
		java.sql.Date date=new java.sql.Date(o1);
		pst.setDate(4, date);
		pst.setString(5, complaint.getSeverity());
		
		pst.executeUpdate();
		return "Record Inserted Sucessfully";
		}
	
	
	
	public Complaint[] ShowComplaint() throws ClassNotFoundException, SQLException {
		connection=ConnectionHelper.getConnection();
		List<Complaint> complaintList = new ArrayList<Complaint>();
		String cmd = "select * from Complaint" ;
		pst=connection.prepareStatement(cmd);
		ResultSet rs= pst.executeQuery();
		Complaint complaint = new Complaint();
		while(rs.next()) {
			complaint = new Complaint();
			complaint.setComplaintID(rs.getInt("ComplaintID"));
			complaint.setComplaintType(rs.getString("ComplaintType"));
			complaint.setcDescription(rs.getString("CDescription"));
			complaint.setComplaintDate(rs.getDate("ComplaintDate"));
			complaint.setSeverity(rs.getString("Severity"));
		
			complaintList.add(complaint);
			
		}
		return complaintList.toArray(new Complaint[complaintList.size()]);
	}
	
	public Complaint searchComplaint(int ComplaintID) throws ClassNotFoundException, SQLException {
		connection= ConnectionHelper.getConnection();
		String cmd="Select * from Complaint where ComplaintID=?";
		pst=connection.prepareStatement(cmd);
		pst.setInt(1, ComplaintID);
		ResultSet rs = pst.executeQuery();
		Complaint complaint = null;
		  if(rs.next()) {
			  complaint = new Complaint();
		complaint.setComplaintID(rs.getInt("ComplaintID"));
		complaint.setComplaintType(rs.getString("ComplaintType"));
		complaint.setComplaintDate(rs.getDate("complaintDate"));
		complaint.setcDescription(rs.getString("CDescription"));
		complaint.setSeverity(rs.getString("Severity"));
		complaint.setStatus((rs.getString("Status")));



		}
		return complaint;
		}
	
	public String resolve(Resolve resolve) throws ClassNotFoundException, SQLException {
		Complaint complaint=searchComplaint(resolve.getComplaintID());
		if(complaint!=null) {
	  connection=ConnectionHelper.getConnection();
			String cmd="insert into resolve(ComplaintID,ComplaintDate,ResolveDate,ResolvedBy,"
					+ "Comments) values(?,?,?,?,?)";
		     pst=connection.prepareStatement(cmd);
			pst.setInt(1, resolve.getComplaintID());
			pst.setDate(2, complaint.getComplaintDate());
			long o1=System.currentTimeMillis();
			java.sql.Date date=new java.sql.Date(o1);
			pst.setDate(3, date);
			pst.setString(4, resolve.getResolvedBy());
			pst.setString(5, resolve.getComments());
			pst.executeUpdate();
			
			cmd="update complaint set status='Resolved' where ComplaintID=?";
			PreparedStatement pst1=connection.prepareStatement(cmd);
			pst1.setInt(1, resolve.getComplaintID());
			pst1.executeUpdate();
			return "Record added";
			
		}
		return "Unknown Complaint ID";

}
	
	 public String check(Complaint comp) throws ClassNotFoundException, SQLException {
			Connection con=ConnectionHelper.getConnection();
			String cmd="select ResolveDate from resolve where ComplaintID=?";
			PreparedStatement pst=con.prepareStatement(cmd);
			pst.setInt(1, comp.getComplaintID());
			ResultSet rs=pst.executeQuery();
			rs.next();
			Date resdate=rs.getDate("ResolveDate");
			long difference = resdate.getTime() - comp.getComplaintDate().getTime();
			int daysBetween = (int) ((difference / (1000 * 60 * 60 * 24))% 365);
			daysBetween++;
			if( daysBetween==1) {
				return "green";
			}else if(daysBetween>=5 && daysBetween<=7) {
				return "pink";
			}else {
				return "red";
			}
			
		}
}











