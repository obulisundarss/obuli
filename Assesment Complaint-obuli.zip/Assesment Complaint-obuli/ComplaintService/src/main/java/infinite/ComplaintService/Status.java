package infinite.ComplaintService;

public enum Status {
	
	
	PENDING, RESOLVED

}
